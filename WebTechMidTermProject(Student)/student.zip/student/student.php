<?php   
    session_start();
    if(!isset($_SESSION['id']) && ($_SESSION['name'])){  
        header("location: login.php");
    }
?>



<html>
    <head>
        <title>Student Portal</title>
    </head>
<center>
<table border="1" width="700px">

       <img src="portal.png" width="300px" height="100px"/>
        
        <h1>Welcome to Student Portal ! <?= $_SESSION['name']?></h1>
    

        <tr>
            <th colspan="2"><br><h2><strong>Student Menu</strong><br></h2></th>
            
        </tr>
        <tr>
            <th colspan="2"><a href="profile.php"><h2><strong><br>Student Profile<br></strong></a></h2></th>
            
        </tr>

        <tr>
            <td><center><a href="reqtoAdm.php"><b>Complaint/Query</b></a><br><br></center> </td>
            <td><center><a href="courses.php"><b>Course Selected</b> </a><br><br></center>
        </td>          
        </tr>
        <tr>
            <td>
                <center><a href="grades.php"><b>Grades</b></a><br><br></center>
            </td>
            <td>
               <center><a href="financial.php"><b>Financal Info</b></a><br><br></center> 
            </td>
        </tr>

        <tr>
            <td>
                <center><a href="classRoutine.php"><b>Class Routine</b></a><br><br></center>
                
            </td>
            <td>
                <center><a href="attendence.php"><b>Attendence Info</b></a><br><br></center>
                
            </td>
        </tr>        

        <tr>
            <td>
                <center><a href="examSchedule.php"><b>Exam Schedule</b></a><br><br></center>
                
            </td>
            <td>
                <center><a href="requestToAdmin.php"><b>Upadte/Delete</b></a><br><br></center>
                
            </td>
        </tr>


        <tr>
            <td><center><a href="library.php"><b>Registered Book's</b></a><br><br></center>
                
            </td>
            <td><center><a href="uploadHW.php"><b>Upload Home Work</b></a><br><br></center>
                
            </td>
        </tr>


        <tr>
            <td>
                <center><a href="contactTeacher.php"><b>Contact Teacher</b></a><br><br></center>
                
            </td>
            <td>
                <center><a href="notices.php"><b>Notices</b></a><br><br></center>
                
            </td>
        </tr>

        <tr>
            <td>
                <center><a href="downloadNotes.php"><b>Note's Download</b></a><br><br></center>
                
            </td>
            <td>
                <center><a href="pollAns.php"><b>Poll Answer</b></a><br><br></center>
                
            </td>

        </tr>

    <tr >
        <td colspan="2"><center><br><a href="logout.php"><b>Log Out</b></a></center><br> </td>
    </tr>
    
    
    
    </center>
</table>
    
    
</html>