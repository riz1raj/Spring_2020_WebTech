<?php   
    session_start();
    if(!isset($_SESSION['id'])){  
        header("location: login.php");
    }
?>

<html>
    <head>
        <title>Notices</title>
    </head>

        <center>
    <fieldset>
        
        <legend><h1><span>Notices By Officials</span></h1></legend>
    
    
   
    <table border="1" width="700px">
        <tr><b>
            <th>Date</th>
            <th>Title</th>
            <th>About</th>
            
            </tr>
        <tr>
            <td>21.02.2020</td>
            <td>Holiday</td>
            <td>Holiday due to mother languages day</td>
            
            
        </tr>
                    

        <tr>
            <td>03.03.2020</td>
            <td>Flood In Kodomtoli</td>
            <td>Due to heavy rains the roads are under water.All classes are canceled</td>
            
            
        </tr>
        <tr>
            <td>04.03.2020</td>
            <td>Mid Exam</td>
            <td>Mid exam will be held from 09.03.2020 .<strong>Must clear your all due payments before exam. Otherwise you won't seat for exam.</strong></td>
        
            
        </tr>
        <tr>
            <td>04.03.1994</td>
            <td>Rules to entry</td>
            <td>1.No ID No Entry<br>
                2.No Shoe No Entry</td>
            
            
        
    </table>
    <br>
    <br>
    <a href="student.php">Student Page</a>
    </center>
    
    
    </fieldset>
    
</html>