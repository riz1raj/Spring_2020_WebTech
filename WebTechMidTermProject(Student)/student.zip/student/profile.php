<?php   
    session_start();
    if(!isset($_SESSION['id'])){  
        header("location: login.php");
    }
?>

<!DOCTYPE html>
<html>
<head>
   
    <title>Profile</title>
</head>
<body>
    <center>
	  <fieldset>
	 <legend><h2> <center>Student Profile</center> </h2></legend> <br>
        
        	
            <table  border="1" width="500px">
               
				<tr>
				
                    <td>
                       <a>ID</a>
                    </td>
					<td>
                       <a><?= $_SESSION['id']?></a>
                    </td>
				
				</tr>
				
				<tr>
				
				<td>
                       <a>Name</a>
                    </td>
					<td>
                       <a>BOB</a>
                    </td>
				</tr>

				<tr>
				
				<td>
                       <a>Department</a>
                    </td>
					<td>
                       <a>Science</a>
                    </td>
				</tr>

				<tr>
				
				<td>
                       <a>Father Name</a>
                    </td>
					<td>
                       <a>Mr.X</a>
                    </td>
				</tr>

				<tr>
				
				<td>
                       <a>Mother Name</a>
                    </td>
					<td>
                       <a>Mrs.Y</a>
                    </td>
				</tr>
				<tr>
				
				<td>
                       <a>Guardian Phone Number</a>
                    </td>
					<td>
                       <a>01777445544</a>
                    </td>
				</tr>

					<tr>
				
				<td>
                       <a>Nationality</a>
                    </td>
					<td>
                       <a>Bangladeshi</a>
                    </td>
				</tr>

					<tr>
				
				<td>
                       <a>Religion</a>
                    </td>
					<td>
                       <a>Islam</a>
                    </td>
				</tr>
				
					<tr>
				
				<td>
                       <a>Blood Group</a>
                    </td>
					<td>
                       <a>O+</a>
                    </td>
				</tr>
				
				
				<tr>
				<td>
                       <a>Gender</a>
                    </td>
					<td>
                       <a>Male</a>
                    </td>
				</tr>
				<tr>
				
				<td>
                       <a>DOB</a>
                    </td>
					<td>
                       <a>16.02.1998</a>
                    </td>
				</tr>
				<tr>
				
				<td>
                       <a>Address</a>
                    </td>
					<td>
                       <a>Uttara Dhaka</a>
                    </td>
				</tr>
				
				<br>
				
				<tr>
				    <td colspan="2" ><br>
				         <center><a href='student.php'><b>Student Page</b></a></center><br>
				    </td>
				</tr>
	    
            </table>
        
        </center>
	    </fieldset>
    </form>
    
</body>
</html>