<?php   
    session_start();
    if(!isset($_SESSION['id'])){  
        header("location: login.php");
    }
?>


<!DOCTYPE html>
<html>
 <head>
        <title>Upload Home Work</title>
</head>

     <center>
<fieldset>
    
    

        
        <legend><h2>Upload Your Home Work Here</h2></legend>
        
        <br>
        <br>
        
        
<form action="upload.php" method="post" enctype="multipart/form-data">
    Select file to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload" name="submit">
</form>

        <br>
        <br>
        

<a href="student.php">Student Page</a>
    </center>

    
</fieldset>

   
<body>


</body>
</html>