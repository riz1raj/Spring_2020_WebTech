<?php   
    session_start();
    if(!isset($_SESSION['id'])){  
        header("location: login.php");
    }
?>
<html>
    <head>
        <title>Poll</title>
    </head>

         <center>
    <fieldset>
       <legend><h1><span>Poll Answer / Your Opinion</span></h1></legend>
    
       <fieldset>

     <b>1. Which date we can take an extra class ?</b><br>
                <input type="radio" name="poll0" value="a">10.04.2020
                <input type="radio" name="poll0" value="b">12.04.2020
                <input type="radio" name="poll0" value="c">14.04.2020
        </fieldset>



                            <br>
                            <br>
    
    <fieldset>
    <b>2. Where you want to go on a study tour ?</b><br>
                <input type="radio" name="poll1" value="Dhaka">Dhaka
                <input type="radio" name="poll1" value="Rajshahi">Rajshahi
                <input type="radio" name="poll1" value="Chittagong">Chittagong
        
    </fieldset>

                            <br>
                            <br>

    <fieldset>
    <b>3. Do you want to attend the seminar tomorrow?</b><br>
                <input type="radio" name="poll2" value="Yes">Yes
                <input type="radio" name="poll2" value="No">No
                <input type="radio" name="poll2" value="Maybe">Maybe
    </fieldset>


    <br>
    <br>

     <input type="submit" name="submit" value="Submit">
    <br>
    <br>
    <a href="student.php">Student Page</a>
    </center>
    
    </fieldset>
    
</html>