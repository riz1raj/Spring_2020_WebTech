
<?php
    session_start();
?>













        <!DOCTYPE html>
                    
             <head>
               <title>Login</title>
             </head>
             
             <body>
             <form action="logchk.php" method="post">
             
             <center>

        <center>
        <img src="studentLogin.jpg" width="300px" height="100px"/>
        </center>
            
        
             <fieldset>
             <legend><b> Student Login</b></legend>
             
             
             <table border="0">
             <tr>
                  <td>
                  User id <br/>
                  <input type="text" name="id" value="">
                  
                  
                
                  
                  
                  </td>
             
             
             </tr>
             <tr>
             <td>
                Password <br/>
                <input type="password" name="pwd" value="">
                
             
             </td>
             </tr>
             
             </tr>
             
             <td>
                
                <input type="submit" name="submit1" value="Login">
                <a href='reg.php'>Register</a>
                
                 
             
             </td>
             </tr>
             
             













                  </html>
      
      