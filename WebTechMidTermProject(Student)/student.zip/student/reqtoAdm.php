<?php   
    session_start();
    if(!isset($_SESSION['id'])){  
        header("location: login.php");
    }
?>

<html>
    <head>
        <title>Request Admin</title>
    </head>

       <center> 
        <fieldset>
            
       <legend><h1><span>Request To Admin</span></h1></legend>    
    

    <strong> If you want to do any complaints/queries </strong><br>
    <br>
    <input type="text" name="Request"> 
    <input type="submit" name="Submit to Admin"><br>
                        <br>
                        <br>

    <a href="student.php">Student Page</a>
    
    </center>
    

        </fieldset>

    
</html>